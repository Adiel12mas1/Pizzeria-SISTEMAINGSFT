/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package control;

import control.exceptions.IllegalOrphanException;
import control.exceptions.NonexistentEntityException;
import java.io.Serializable;
import javax.persistence.Query;
import javax.persistence.EntityNotFoundException;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import modelo.Productos;
/**
 *
 * @author noobe
 */
public class ProductosJpaController implements Serializable {

    public ProductosJpaController(EntityManagerFactory emf) {
        this.emf = emf;
    }
    private EntityManagerFactory emf = null;

    public EntityManager getEntityManager() {
        return emf.createEntityManager();
    }

    public void create(Productos productos) {
        if (productos.getPedidoProductoCollection() == null) {
            productos.setPedidoProductoCollection(new ArrayList<PedidoProducto>());
        }
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            Collection<PedidoProducto> attachedPedidoProductoCollection = new ArrayList<PedidoProducto>();
            for (PedidoProducto pedidoProductoCollectionPedidoProductoToAttach : productos.getPedidoProductoCollection()) {
                pedidoProductoCollectionPedidoProductoToAttach = em.getReference(pedidoProductoCollectionPedidoProductoToAttach.getClass(), pedidoProductoCollectionPedidoProductoToAttach.getIdPedidoProducto());
                attachedPedidoProductoCollection.add(pedidoProductoCollectionPedidoProductoToAttach);
            }
            productos.setPedidoProductoCollection(attachedPedidoProductoCollection);
            em.persist(productos);
            for (PedidoProducto pedidoProductoCollectionPedidoProducto : productos.getPedidoProductoCollection()) {
                Productos oldIdProductoOfPedidoProductoCollectionPedidoProducto = pedidoProductoCollectionPedidoProducto.getIdProducto();
                pedidoProductoCollectionPedidoProducto.setIdProducto(productos);
                pedidoProductoCollectionPedidoProducto = em.merge(pedidoProductoCollectionPedidoProducto);
                if (oldIdProductoOfPedidoProductoCollectionPedidoProducto != null) {
                    oldIdProductoOfPedidoProductoCollectionPedidoProducto.getPedidoProductoCollection().remove(pedidoProductoCollectionPedidoProducto);
                    oldIdProductoOfPedidoProductoCollectionPedidoProducto = em.merge(oldIdProductoOfPedidoProductoCollectionPedidoProducto);
                }
            }
            em.getTransaction().commit();
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void edit(Productos productos) throws IllegalOrphanException, NonexistentEntityException, Exception {
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            Productos persistentProductos = em.find(Productos.class, productos.getIdProducto());
            Collection<PedidoProducto> pedidoProductoCollectionOld = persistentProductos.getPedidoProductoCollection();
            Collection<PedidoProducto> pedidoProductoCollectionNew = productos.getPedidoProductoCollection();
            List<String> illegalOrphanMessages = null;
            for (PedidoProducto pedidoProductoCollectionOldPedidoProducto : pedidoProductoCollectionOld) {
                if (!pedidoProductoCollectionNew.contains(pedidoProductoCollectionOldPedidoProducto)) {
                    if (illegalOrphanMessages == null) {
                        illegalOrphanMessages = new ArrayList<String>();
                    }
                    illegalOrphanMessages.add("You must retain PedidoProducto " + pedidoProductoCollectionOldPedidoProducto + " since its idProducto field is not nullable.");
                }
            }
            if (illegalOrphanMessages != null) {
                throw new IllegalOrphanException(illegalOrphanMessages);
            }
            Collection<PedidoProducto> attachedPedidoProductoCollectionNew = new ArrayList<PedidoProducto>();
            for (PedidoProducto pedidoProductoCollectionNewPedidoProductoToAttach : pedidoProductoCollectionNew) {
                pedidoProductoCollectionNewPedidoProductoToAttach = em.getReference(pedidoProductoCollectionNewPedidoProductoToAttach.getClass(), pedidoProductoCollectionNewPedidoProductoToAttach.getIdPedidoProducto());
                attachedPedidoProductoCollectionNew.add(pedidoProductoCollectionNewPedidoProductoToAttach);
            }
            pedidoProductoCollectionNew = attachedPedidoProductoCollectionNew;
            productos.setPedidoProductoCollection(pedidoProductoCollectionNew);
            productos = em.merge(productos);
            for (PedidoProducto pedidoProductoCollectionNewPedidoProducto : pedidoProductoCollectionNew) {
                if (!pedidoProductoCollectionOld.contains(pedidoProductoCollectionNewPedidoProducto)) {
                    Productos oldIdProductoOfPedidoProductoCollectionNewPedidoProducto = pedidoProductoCollectionNewPedidoProducto.getIdProducto();
                    pedidoProductoCollectionNewPedidoProducto.setIdProducto(productos);
                    pedidoProductoCollectionNewPedidoProducto = em.merge(pedidoProductoCollectionNewPedidoProducto);
                    if (oldIdProductoOfPedidoProductoCollectionNewPedidoProducto != null && !oldIdProductoOfPedidoProductoCollectionNewPedidoProducto.equals(productos)) {
                        oldIdProductoOfPedidoProductoCollectionNewPedidoProducto.getPedidoProductoCollection().remove(pedidoProductoCollectionNewPedidoProducto);
                        oldIdProductoOfPedidoProductoCollectionNewPedidoProducto = em.merge(oldIdProductoOfPedidoProductoCollectionNewPedidoProducto);
                    }
                }
            }
            em.getTransaction().commit();
        } catch (Exception ex) {
            String msg = ex.getLocalizedMessage();
            if (msg == null || msg.length() == 0) {
                Integer id = productos.getIdProducto();
                if (findProductos(id) == null) {
                    throw new NonexistentEntityException("The productos with id " + id + " no longer exists.");
                }
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void destroy(Integer id) throws IllegalOrphanException, NonexistentEntityException {
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            Productos productos;
            try {
                productos = em.getReference(Productos.class, id);
                productos.getIdProducto();
            } catch (EntityNotFoundException enfe) {
                throw new NonexistentEntityException("The productos with id " + id + " no longer exists.", enfe);
            }
            List<String> illegalOrphanMessages = null;
            Collection<PedidoProducto> pedidoProductoCollectionOrphanCheck = productos.getPedidoProductoCollection();
            for (PedidoProducto pedidoProductoCollectionOrphanCheckPedidoProducto : pedidoProductoCollectionOrphanCheck) {
                if (illegalOrphanMessages == null) {
                    illegalOrphanMessages = new ArrayList<String>();
                }
                illegalOrphanMessages.add("This Productos (" + productos + ") cannot be destroyed since the PedidoProducto " + pedidoProductoCollectionOrphanCheckPedidoProducto + " in its pedidoProductoCollection field has a non-nullable idProducto field.");
            }
            if (illegalOrphanMessages != null) {
                throw new IllegalOrphanException(illegalOrphanMessages);
            }
            em.remove(productos);
            em.getTransaction().commit();
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public List<Productos> findProductosEntities() {
        return findProductosEntities(true, -1, -1);
    }

    public List<Productos> findProductosEntities(int maxResults, int firstResult) {
        return findProductosEntities(false, maxResults, firstResult);
    }

    private List<Productos> findProductosEntities(boolean all, int maxResults, int firstResult) {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            cq.select(cq.from(Productos.class));
            Query q = em.createQuery(cq);
            if (!all) {
                q.setMaxResults(maxResults);
                q.setFirstResult(firstResult);
            }
            return q.getResultList();
        } finally {
            em.close();
        }
    }

    public Productos findProductos(Integer id) {
        EntityManager em = getEntityManager();
        try {
            return em.find(Productos.class, id);
        } finally {
            em.close();
        }
    }

    public int getProductosCount() {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            Root<Productos> rt = cq.from(Productos.class);
            cq.select(em.getCriteriaBuilder().count(rt));
            Query q = em.createQuery(cq);
            return ((Long) q.getSingleResult()).intValue();
        } finally {
            em.close();
        }
    }
    
}
