/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package control;

import control.exceptions.IllegalOrphanException;
import control.exceptions.NonexistentEntityException;
import java.io.Serializable;
import javax.persistence.Query;
import javax.persistence.EntityNotFoundException;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.NoResultException;
import javax.persistence.TypedQuery;
import modelo.Usuarios;
import modelo.Pedidos;
import modelo.Notificaciones;
/**
 *
 * @author noobe
 */
public class UsuariosJpaController implements Serializable {

    public UsuariosJpaController(EntityManagerFactory emf) {
        this.emf = emf;
    }
    private EntityManagerFactory emf = null;

    public EntityManager getEntityManager() {
        return emf.createEntityManager();
    }
    
    public Usuarios findUsuarioByCorreo(String correo) {
    EntityManager em = getEntityManager();
    try {
        return (Usuarios) em.createQuery("SELECT u FROM Usuarios u WHERE u.correo = :correo")
                            .setParameter("correo", correo)
                            .getSingleResult();
    } catch (javax.persistence.NoResultException e) {
        return null;
    }
}

    public void create(Usuarios usuarios) {
        if (usuarios.getNotificacionesCollection() == null) {
            usuarios.setNotificacionesCollection(new ArrayList<Notificaciones>());
        }
        if (usuarios.getPedidosCollection() == null) {
            usuarios.setPedidosCollection(new ArrayList<Pedidos>());
        }
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            Collection<Notificaciones> attachedNotificacionesCollection = new ArrayList<Notificaciones>();
            for (Notificaciones notificacionesCollectionNotificacionesToAttach : usuarios.getNotificacionesCollection()) {
                notificacionesCollectionNotificacionesToAttach = em.getReference(notificacionesCollectionNotificacionesToAttach.getClass(), notificacionesCollectionNotificacionesToAttach.getIdNotificacion());
                attachedNotificacionesCollection.add(notificacionesCollectionNotificacionesToAttach);
            }
            usuarios.setNotificacionesCollection(attachedNotificacionesCollection);
            Collection<Pedidos> attachedPedidosCollection = new ArrayList<Pedidos>();
            for (Pedidos pedidosCollectionPedidosToAttach : usuarios.getPedidosCollection()) {
                pedidosCollectionPedidosToAttach = em.getReference(pedidosCollectionPedidosToAttach.getClass(), pedidosCollectionPedidosToAttach.getIdPedido());
                attachedPedidosCollection.add(pedidosCollectionPedidosToAttach);
            }
            usuarios.setPedidosCollection(attachedPedidosCollection);
            em.persist(usuarios);
            for (Notificaciones notificacionesCollectionNotificaciones : usuarios.getNotificacionesCollection()) {
                Usuarios oldIdUsuarioOfNotificacionesCollectionNotificaciones = notificacionesCollectionNotificaciones.getIdUsuario();
                notificacionesCollectionNotificaciones.setIdUsuario(usuarios);
                notificacionesCollectionNotificaciones = em.merge(notificacionesCollectionNotificaciones);
                if (oldIdUsuarioOfNotificacionesCollectionNotificaciones != null) {
                    oldIdUsuarioOfNotificacionesCollectionNotificaciones.getNotificacionesCollection().remove(notificacionesCollectionNotificaciones);
                    oldIdUsuarioOfNotificacionesCollectionNotificaciones = em.merge(oldIdUsuarioOfNotificacionesCollectionNotificaciones);
                }
            }
            for (Pedidos pedidosCollectionPedidos : usuarios.getPedidosCollection()) {
                Usuarios oldIdUsuarioOfPedidosCollectionPedidos = pedidosCollectionPedidos.getIdUsuario();
                pedidosCollectionPedidos.setIdUsuario(usuarios);
                pedidosCollectionPedidos = em.merge(pedidosCollectionPedidos);
                if (oldIdUsuarioOfPedidosCollectionPedidos != null) {
                    oldIdUsuarioOfPedidosCollectionPedidos.getPedidosCollection().remove(pedidosCollectionPedidos);
                    oldIdUsuarioOfPedidosCollectionPedidos = em.merge(oldIdUsuarioOfPedidosCollectionPedidos);
                }
            }
            em.getTransaction().commit();
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void edit(Usuarios usuarios) throws IllegalOrphanException, NonexistentEntityException, Exception {
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            Usuarios persistentUsuarios = em.find(Usuarios.class, usuarios.getIdUsuario());
            Collection<Notificaciones> notificacionesCollectionOld = persistentUsuarios.getNotificacionesCollection();
            Collection<Notificaciones> notificacionesCollectionNew = usuarios.getNotificacionesCollection();
            Collection<Pedidos> pedidosCollectionOld = persistentUsuarios.getPedidosCollection();
            Collection<Pedidos> pedidosCollectionNew = usuarios.getPedidosCollection();
            List<String> illegalOrphanMessages = null;
            for (Notificaciones notificacionesCollectionOldNotificaciones : notificacionesCollectionOld) {
                if (!notificacionesCollectionNew.contains(notificacionesCollectionOldNotificaciones)) {
                    if (illegalOrphanMessages == null) {
                        illegalOrphanMessages = new ArrayList<String>();
                    }
                    illegalOrphanMessages.add("You must retain Notificaciones " + notificacionesCollectionOldNotificaciones + " since its idUsuario field is not nullable.");
                }
            }
            for (Pedidos pedidosCollectionOldPedidos : pedidosCollectionOld) {
                if (!pedidosCollectionNew.contains(pedidosCollectionOldPedidos)) {
                    if (illegalOrphanMessages == null) {
                        illegalOrphanMessages = new ArrayList<String>();
                    }
                    illegalOrphanMessages.add("You must retain Pedidos " + pedidosCollectionOldPedidos + " since its idUsuario field is not nullable.");
                }
            }
            if (illegalOrphanMessages != null) {
                throw new IllegalOrphanException(illegalOrphanMessages);
            }
            Collection<Notificaciones> attachedNotificacionesCollectionNew = new ArrayList<Notificaciones>();
            for (Notificaciones notificacionesCollectionNewNotificacionesToAttach : notificacionesCollectionNew) {
                notificacionesCollectionNewNotificacionesToAttach = em.getReference(notificacionesCollectionNewNotificacionesToAttach.getClass(), notificacionesCollectionNewNotificacionesToAttach.getIdNotificacion());
                attachedNotificacionesCollectionNew.add(notificacionesCollectionNewNotificacionesToAttach);
            }
            notificacionesCollectionNew = attachedNotificacionesCollectionNew;
            usuarios.setNotificacionesCollection(notificacionesCollectionNew);
            Collection<Pedidos> attachedPedidosCollectionNew = new ArrayList<Pedidos>();
            for (Pedidos pedidosCollectionNewPedidosToAttach : pedidosCollectionNew) {
                pedidosCollectionNewPedidosToAttach = em.getReference(pedidosCollectionNewPedidosToAttach.getClass(), pedidosCollectionNewPedidosToAttach.getIdPedido());
                attachedPedidosCollectionNew.add(pedidosCollectionNewPedidosToAttach);
            }
            pedidosCollectionNew = attachedPedidosCollectionNew;
            usuarios.setPedidosCollection(pedidosCollectionNew);
            usuarios = em.merge(usuarios);
            for (Notificaciones notificacionesCollectionNewNotificaciones : notificacionesCollectionNew) {
                if (!notificacionesCollectionOld.contains(notificacionesCollectionNewNotificaciones)) {
                    Usuarios oldIdUsuarioOfNotificacionesCollectionNewNotificaciones = notificacionesCollectionNewNotificaciones.getIdUsuario();
                    notificacionesCollectionNewNotificaciones.setIdUsuario(usuarios);
                    notificacionesCollectionNewNotificaciones = em.merge(notificacionesCollectionNewNotificaciones);
                    if (oldIdUsuarioOfNotificacionesCollectionNewNotificaciones != null && !oldIdUsuarioOfNotificacionesCollectionNewNotificaciones.equals(usuarios)) {
                        oldIdUsuarioOfNotificacionesCollectionNewNotificaciones.getNotificacionesCollection().remove(notificacionesCollectionNewNotificaciones);
                        oldIdUsuarioOfNotificacionesCollectionNewNotificaciones = em.merge(oldIdUsuarioOfNotificacionesCollectionNewNotificaciones);
                    }
                }
            }
            for (Pedidos pedidosCollectionNewPedidos : pedidosCollectionNew) {
                if (!pedidosCollectionOld.contains(pedidosCollectionNewPedidos)) {
                    Usuarios oldIdUsuarioOfPedidosCollectionNewPedidos = pedidosCollectionNewPedidos.getIdUsuario();
                    pedidosCollectionNewPedidos.setIdUsuario(usuarios);
                    pedidosCollectionNewPedidos = em.merge(pedidosCollectionNewPedidos);
                    if (oldIdUsuarioOfPedidosCollectionNewPedidos != null && !oldIdUsuarioOfPedidosCollectionNewPedidos.equals(usuarios)) {
                        oldIdUsuarioOfPedidosCollectionNewPedidos.getPedidosCollection().remove(pedidosCollectionNewPedidos);
                        oldIdUsuarioOfPedidosCollectionNewPedidos = em.merge(oldIdUsuarioOfPedidosCollectionNewPedidos);
                    }
                }
            }
            em.getTransaction().commit();
        } catch (Exception ex) {
            String msg = ex.getLocalizedMessage();
            if (msg == null || msg.length() == 0) {
                Integer id = usuarios.getIdUsuario();
                if (findUsuarios(id) == null) {
                    throw new NonexistentEntityException("The usuarios with id " + id + " no longer exists.");
                }
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void destroy(Integer id) throws IllegalOrphanException, NonexistentEntityException {
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            Usuarios usuarios;
            try {
                usuarios = em.getReference(Usuarios.class, id);
                usuarios.getIdUsuario();
            } catch (EntityNotFoundException enfe) {
                throw new NonexistentEntityException("The usuarios with id " + id + " no longer exists.", enfe);
            }
            List<String> illegalOrphanMessages = null;
            Collection<Notificaciones> notificacionesCollectionOrphanCheck = usuarios.getNotificacionesCollection();
            for (Notificaciones notificacionesCollectionOrphanCheckNotificaciones : notificacionesCollectionOrphanCheck) {
                if (illegalOrphanMessages == null) {
                    illegalOrphanMessages = new ArrayList<String>();
                }
                illegalOrphanMessages.add("This Usuarios (" + usuarios + ") cannot be destroyed since the Notificaciones " + notificacionesCollectionOrphanCheckNotificaciones + " in its notificacionesCollection field has a non-nullable idUsuario field.");
            }
            Collection<Pedidos> pedidosCollectionOrphanCheck = usuarios.getPedidosCollection();
            for (Pedidos pedidosCollectionOrphanCheckPedidos : pedidosCollectionOrphanCheck) {
                if (illegalOrphanMessages == null) {
                    illegalOrphanMessages = new ArrayList<String>();
                }
                illegalOrphanMessages.add("This Usuarios (" + usuarios + ") cannot be destroyed since the Pedidos " + pedidosCollectionOrphanCheckPedidos + " in its pedidosCollection field has a non-nullable idUsuario field.");
            }
            if (illegalOrphanMessages != null) {
                throw new IllegalOrphanException(illegalOrphanMessages);
            }
            em.remove(usuarios);
            em.getTransaction().commit();
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public List<Usuarios> findUsuariosEntities() {
        return findUsuariosEntities(true, -1, -1);
    }

    public List<Usuarios> findUsuariosEntities(int maxResults, int firstResult) {
        return findUsuariosEntities(false, maxResults, firstResult);
    }

    private List<Usuarios> findUsuariosEntities(boolean all, int maxResults, int firstResult) {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            cq.select(cq.from(Usuarios.class));
            Query q = em.createQuery(cq);
            if (!all) {
                q.setMaxResults(maxResults);
                q.setFirstResult(firstResult);
            }
            return q.getResultList();
        } finally {
            em.close();
        }
    }

    public Usuarios findUsuarios(Integer id) {
        EntityManager em = getEntityManager();
        try {
            return em.find(Usuarios.class, id);
        } finally {
            em.close();
        }
    }

    public int getUsuariosCount() {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            Root<Usuarios> rt = cq.from(Usuarios.class);
            cq.select(em.getCriteriaBuilder().count(rt));
            Query q = em.createQuery(cq);
            return ((Long) q.getSingleResult()).intValue();
        } finally {
            em.close();
        }
    }
    
    
    public Usuarios verificarUsuarios(String correo, String contraseña){
        EntityManager em = getEntityManager();
        try{
            TypedQuery<Usuarios> query = em.createQuery(
                    "SELECT u FROM Usuarios u WHERE U.correo = :correo AND u.contraseña = :contraseña", Usuarios.class
            );
            query.setParameter("correo", correo);
            query.setParameter("contraseña", contraseña);
            
            return query.getSingleResult();
        } catch (NoResultException e){
            return null;
        } finally {
            em.close();
        }
    }
}
